<?php
session_start();

	include("classes/Connection_Class.php");
	include("classes/Login_Class.php");

	
	$ID_number="";
	$Password="";


	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		$login= new Login();
		$result = $login->evaluate($_POST);

		if($result !="")
		{
			echo "<div style='text-align:center;font-size:15px;color:gold;background color:#3c5a99;'>";
			echo "The Following Errors Occured<br><br>";
			echo $result;
			echo "</div>";
		}else
		{
			header("Location: Profile.php");
			die;
		}

		
		$ID_number=$_POST['ID_number'];
		$Password=$_POST['Password'];

	}
   
?>
<!DOCTYPE html>
<html>
<head>

	<title>MPAAA Login Page</title>

</head>

	<style>
		#Bar{
			height:100px;
			background-color:#3c5a99;
			color:gold;
			padding: 4px;
			text-align: center;

		}
		#Signup_button{
			color:#d9dfeb;
			background-color: green;
			width: 60px;
			text-align: center;
			padding: 4px;
			border-radius: 4px;
			float: left;
		}

		#Log-in{

			background-color: #f7f7f7;
			width: 600px;
			margin: auto;
			margin-top: 50px;
			padding: 10px;
			padding-top: 50px;
			text-align: center;
			font-weight: bold;
		}
		#text{
			height: 40px;
			width: 300px;
			border-radius: 4px;
			border: solid 1px #ddd;
			padding: 4px;
			font-size: 14px;

		}
		#button{
			width: 300px;
			height: 40px;
			border-radius: 4px;
			font-weight: bold;
			border:none;
			background-color:#3c5a99;
			color: white;
		}
	
	</style>

	<body style="font-family: tahoma;background-color: #e9ebee;background-image: url(crown.jpg);">
		<div id="Bar">

			<div style="font-size: 40px;">
			Minor's Protection Against Alcohol Abuse(M.P.A.A.A)
			</div>

		</div>
			<div id="Log-in">
				Log-in To PROTECTION<br>
				<form method="post">
					<input value="<?php echo $ID_number ?>" name="ID_number" type="text" id="text" placeholder="Please Enter ID/Username"><br><br>
				<input value="<?php echo $Password ?>" name="Password" type="Password" id="text" placeholder="Please Enter Password"><br><br>
				<input name="Log-in"type="submit" id="button" value="Log-in"><br><br><br>

				</form>
				
				<section>
					<a href="AboutUs.php">Learn more about the goal and future of this website</a><br><br>
					<a href="MPAAA_sign-up_page.php">Don't have an Account? Create one here.</a>
				</section>


			</div>
		

	</body>
</html>