<?php

session_start();

if(isset($_SESSION['MPAAA_ID_number']))
{
	$_SESSION['MPAAA_ID_number']= NULL;
	unset($_SESSION['MPAAA_ID_number']);
}

header("Location: MPAAA_login_page.php");
die;