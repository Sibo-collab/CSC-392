<?php

	include("classes/Connection_Class.php");
	include("classes/Sign-up_Class.php");

	$Firstname="";
	$Lastname="";
	$Gender="";
	$ID_number="";
	$Email="";


	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		$signup= new Signup();
		$result = $signup->evaluate($_POST);

		if($result !="")
		{
			echo "<div style='text-align:center;font-size:15px;color:gold;background color:#3c5a99;'>";
				echo "The Following Errors Occured<br><br>";
				echo $result;
				echo "</div>";


		}else
		{
			
			header("Location: MPAAA_login_page.php");
			echo '<script> alert( "Congratulations on Creating an Account!! \n\n Press OK to continue" ) </script>';
		}

		$Firstname=mysqli_real_string_escape($con,$_POST['Firstname']);
		$Lastname=mysqli_real_string_escape($con,$_POST['Lastname']);
		$Gender=mysqli_real_string_escape($con,$_POST['Gender']);
		$ID_number=mysqli_real_string_escape($con,$_POST['ID_number']);
		$Email=mysqli_real_string_escape($con,$_POST['Email']);
	}
   
?>

<html>
<head>

	<title>MPAAA Sign-up Page</title>

</head>

	<style>
		#Bar{
			height:100px;
			background-color:#3c5a99;
			color:gold;
			padding: 4px;
			text-align: center;
			

		}
		#Signup_button{
			color:#d9dfeb;
			background-color: green;
			width: 60px;
			text-align: center;
			padding: 4px;
			border-radius: 4px;
			float: right;
		}

		#Log-in{

			background-color: #f7f7f7;
			width: 600px;
			margin: auto;
			margin-top: 50px;
			padding: 10px;
			padding-top: 50px;
			text-align: center;
			font-weight: bold;
		}
		#text{
			height: 40px;
			width: 300px;
			border-radius: 4px;
			border: solid 1px #ddd;
			padding: 4px;
			font-size: 14px;

		}
		#button{
			width: 300px;
			height: 40px;
			border-radius: 4px;
			font-weight: bold;
			border:none;
			background-color:#3c5a99;
			color: white;
		}
	
	</style>

	<body style="font-family: tahoma;background-color: #e9ebee;background-image: url(crown.jpg);">
		<div id="Bar">

			<div style="font-size:40px;">
			Minor's Protection Against Alcohol Abuse(M.P.A.A.A)
			</div>

		</div>
			<div id="Log-in">
				Sign-up To PROTECTION<br><br>

				<form method="post" action= "">

					<input value="<?php echo $Firstname ?>" name="Firstname" type="text" id="text" placeholder="Please Enter Firstname"><br><br>

					<input value="<?php echo $Lastname ?>" name="Lastname" type="text" id="text" placeholder="Please Enter Lastname"><br><br>

					<span style="font-weight: normal;">Gender:</span><br>
					<select id="text" value="<?php echo $Gender ?>" name = "Gender">

						<option>Male</option>
						<option>Female</option>

					</select><br><br> 
					
					<input value="<?php echo $ID_number ?>" name="ID_number" type="Password" id="text" placeholder="Please Enter ID number"><br><br>
					
					<input value="<?php echo $Email ?>" name="Email" type="text" id="text" placeholder="Please Enter Email"><br><br>

					<input  name="Password" type="Password" id="text" placeholder="Please Enter Password"><br><br>

					<input name="c_password" type="Password" id="text" placeholder="Please re-Enter Password"><br><br>

					<input type="submit" id="button" value="Sign-up" name = "Sign-up"><br><br><br> 

				</form>
				
				<a href="MPAAA_login_page.php">Already Have An Account? Log-in Here</a><br><br>
				<a href="AboutUs.php">Read more about our Mission</a>

			</div>


	</body>
	

</html>