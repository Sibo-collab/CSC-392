<?php
session_start();
//print_r($_SESSION);


include("classes/Connection_Class.php");
include("classes/Login_Class.php");
include("classes/Users.php");
include("classes/SalesSign-up_class.php");
if(isset($_SESSION['MPAAA_ID_number'])&&is_numeric($_SESSION['MPAAA_ID_number']) )
{
	$id = $_SESSION['MPAAA_ID_number'];
	$login=new Login();
	$login->check_login($id);

	$result = $login->check_login($id);

	if($result)
	{
		//retrieve user data
		$user = new User();
		$user_data = $user->get_data($id);
		//$greeting=new Greeting;
 		//$greeting->greeting();

		$Firstname="";
		$Lastname="";
		$DOB="";
		$PIN="";
		$gender="";
		$SalesDetails="";
		$Amount="";


		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{

			$signup= new SalesSignup();
			$result = $signup->evaluate($_POST);

			if($result !="")
			{

				echo "<div style='text-align:center;font-size:15px;color:gold;background color:#3c5a99;'>";
				echo "The Following Errors Occured<br><br>";
				echo $result;
				echo "</div>";
			}else
			{
				die;
			}

			$Firstname=mysqli_real_escape_string($con,$_POST['Firstname']);
			$Lastname=mysqli_real_escape_string($con,$_POST['Lastname']);
			$DOB=($_POST['DOB']);

			$PIN=mysqli_real_escape_string($con,$_POST['PIN']);
			$gender=mysqli_real_escape_string($con,$_POST['gender']);
			$SalesDetails=mysqli_real_escape_string($con,$_POST['SalesDetails']);
			$Amount=mysqli_real_escape_string($con,$_POST['Amount']);
		}

		if(!$user_data)
		{
			header("Location: MPAAA_login_page.php");
			die;
		}

	}else
	{
		header("Location: MPAAA_login_page.php");
		die;
	}
}else
	{
		header("Location: MPAAA_login_page.php");
		die;
	}
 



	

?>
<!DOCTYPE html>
	<html>
	<head>

		<style type="text/css">
			#blue_bar{

				background-color: #405d9b;
				color: gold;
				height: 80px;
			}
			#Search_box{
				width: 400px;
				border-radius: 5px;
				border:none;
				padding: 4px;
				margin: auto;
				background-image: url(search03.png) ;
				background-repeat: no-repeat;
				background-position: right;
			}
			#profile_pic{
				width: 150px;
				margin-top: -150px;
				border-radius: 50%;
				border:solid 2px white;
			}
			#task_bar{

				width: 250px;
				background-color:#405d9b;
				display: inline-block;
				text-align: center;
				border-radius: 4px;
				border: solid black 3px;
				padding: 4px;
				margin: auto;
				color: gold;

			}
			#Menu{
				height: 60px;
				text-align: center;
				border: 3px;
				padding: 5px;
				color:#405d9b;
				background-color: #f7f7f7;
			}
			#Sign-up_button{
			color:#d9dfeb;
			background-color: green;
			width: 60px;
			text-align: center;
			padding: 4px;
			border-radius: 4px;
			float: right;
		}
		#text{
			height: 40px;
			width: 300px;
			border-radius: 4px;
			border: solid 1px #ddd;
			padding: 4px;
			font-size: 14px;

		}
		#button{
			width: 300px;
			height: 40px;
			border-radius: 4px;
			font-weight: bold;
			border:none;
			background-color:#3c5a99;
			color: gold;
		}
		#SaleDetails{

			background-color: #f7f7f7;
			margin: auto;
			min-width: 20px;
			display:inline-block;
			min-height: 400px;
			margin-top: 50px;
			padding: 10px;
			padding-top: 50px;
			text-align: center;
			font-weight: bold;
		}

		</style>
		<title>ProfilePage</title>
	</head>
	<body style="font-family: tahoma;background-color:#f7f7f7;">


		<!--top bar-->
		<div id="blue_bar">
			<div style="width: 800px;font-size: 30px;margin: auto;">

				MPAAA &nbsp&nbsp<input type="text" id="Search_box" placeholder="Enter search">&nbsp
				<img src="Flag-of-Swaziland.png"style="width:80px;margin: auto;float: right;border-radius: 50%;">
				<a href="Log-out.php">
				<span style="font-size: 20px;float: right;margin: 10px;color: gold;">Log-out</span></a>
			</div><br>
		
		</div>
		<!--cover area-->
		<div style="width: 800px; margin: auto;background-color: #f7f7f7;">
			<div style="background-color: #f7f7f7;text-align: center;color:#405d9b;">
				<img src="symbol.jpg"style="width:100%;">
				<img src="Earth03.jpg" id="profile_pic"><br>
				<div style="font-size: 20px;color: black;"><?php echo $user_data['Firstname']." " .$user_data['Lastname']?></div><br>

			</div>
		</div>

		<div id="Menu">
			<br>
			<div id="task_bar">Verify Sale</div>&nbsp
			<div id="task_bar">Customize Profile</div>&nbsp
			<div id="task_bar">Settings</div>
		</div>

			<div style="display: flex;min-height:400px;width: 100%;background-color: #f7f7f7;">
				
				<div id="SaleDetails" style="flex:1;min-height:600px; background-image: url(ice.jpg);"></div>&nbsp
				<div id="SaleDetails" style="flex:2;background-color:grey;background-image: url(Esw.jpg);">Sale Verification<br><br>

				<form method="post" action= "Profile.php">

					
					<input  name="Firstname" type="text" id="text" placeholder="Please Enter Firstname"><br><br>
					<input  name="Lastname" type="text" id="text" placeholder="Please Enter Lastname"><br><br>
					<input id="text" type="datetime-local" name="DOB" placeholder="Please Enter DOB" class="form-control" /><br><br>
					<input  name="PIN" type="Password" id="text" placeholder="Please Enter PIN"><br><br>
					<span style="font-weight: normal;">gender:</span><br>
					<select id="text" name = "gender">
						<option>Male</option>
						<option>Female</option>
					</select><br><br>					
					<input name="SalesDetails" type="text" id="text" placeholder="Please Enter SalesDetails"><br><br>
					<input  name="Amount" type="text" id="text" placeholder="Please Enter Amount"><br><br>					
					<input type="submit" id="button" value="Verify" name = "Verify"><br><br><br> 
				</form>	</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">alert("WELCOME! <?php echo $user_data['Firstname']." " .$user_data['Lastname']?>, you have Successfully Loged-In\n.<?php $greeting=new Greeting;$greeting->greeting(); ?>")</script>
		 </html>

