<html>
	<title>
		AboutUs
	</title>
		<style>
			#Top_bar{

			
				background-color:#405d9b;
				color: gold;
				padding: 4px;
			}

			#drug_and_acohol_photos{
			
				display: inline-block;

			}
		
		</style>

	<body style="margin:auto;text-align: center; font-size: 25px;background-size: cover;background-color: #f7f7f7;">
			<div id="Top_bar">
				<section>
					<h1>
						Minors Protection Against Alcohol Abuse(M.P.A.A.A) WEB-APP 
					</h1>
			</div>

			<div id="Sample_Photo" style="background-color: #f7f7f7;">
				<img src="national-flag.jpg">
			</div>


			<div style="background-color:#f7f7f7">
				<h2>
					Problem Statement
				</h2>
					<p>
						The Kingdom of Eswatini is facing a real-world challenge caused by the lack of regulation of bottle stores/liquor stores, causing the youth/minors to have access to age restricted substances(alcohol) that are highly addictive.
					</p>

					<div style="background-color:#f7f7f7" id="drug_and_alcohol_photos">
						<img src="images.jpeg">&nbsp<img src="alcohol.jpg">
					</div>
		
			</div>

		<h2>
			<b>
				Requirement/Theoretical Solution
			</b>
		</h2>

		<p>
			A system that will require a customer to present legal documentation (Eswatini National ID) at the check-out booth and verify the legitimacy of the presented document prior to the purchase of any alcoholic/controlled substances.
		</p>

		<div>
			<h1>
				<b>
					AIM
				</b>
			</h1>

			<p>
				To prevent the sale of alcohol and other addictive substances to minors.
				<p>
					<video src="aware.org.mp4" controls type="video/mp4" width="800"></video>
				</p>
			</p>
		</div>

		<h1>
			<b>
				Overall aim
			</b>
		</h1>

		<p>
			To pioneer a new system aimed to protect minors from alcohol abuse prompting a new legislation by a governing body requiring all liquor vendors nationwide to implement the system as the primary solution to the underage drinking crisis in the Kingdom.
		</p>

		<h1>
			<b>
				Initial Starting Point and Overall Direction
			</b>
		</h1>

		<p>
			During the early stages of implementation, the system will merely be a website linked to the Eswatini Citizens database in order to verify that customers are of legal age (18+) prior to liquor vendors completing each liquor sale.
		</p>

		<h4>
			<b>The end goal is to influence the improvement of:</b>
		</h4>

		<ol>
			<li>
				<p>
					<b>	ID card itself
					</b>- the ID card should have a magnetic stripe and QR code so that rather than manually inputting the customer data on the website, cashiers (in a business context for example) can simply swipe the card and the website will do the rest, issuing a notice in case there is a violation of liquor sale laws in the country. The QR code will serve as an alternative to swiping where the QR code can simply be scanned, and the data retrieved to complete all necessary verification before the sale.
				</p>
			</li>

			<li>
				<p>

					<b>
						Identity Verification Technology
					</b>
						- the concept used to combat the underage drinking crisis using the website will shift from just a website to a stand-alone special computer with native software that will handle liquor sales and will continue to be developed to support other activities where secure identity verification is a key process (e.g. collecting government support money (grant)). This new technology should be able to support the updated/improved ID card standards outlined in the above paragraph.
				</p>
			</li>
			
		</ol>

		</section>
		
		<section>
			<a href="MPAAA_login_page.php">Home</a>
		</section>
		
		</div>
		
	</body>
</html>