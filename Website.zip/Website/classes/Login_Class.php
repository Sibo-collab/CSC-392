<?php
//Set Timezone
date_default_timezone_set('Africa/Mbabane');
//display the date and time with a greeting
class Greeting
{

	public function greeting()
	{
		$Hour=date('H');
		if($Hour<12)
		{
			echo " Good Morning!!!";
		}elseif($Hour>12&& $Hour<18)
		{
			echo " Good afternoon!!!";
		}else
		{
			echo " Good Evening!!!";
		}
	}

}
class Login
{
	private $error = "";

	
	public function evaluate($data)
	{
		
		$ID_number = addslashes($data['ID_number']);
		$Password = addslashes($data['Password']);

		$query = "select * from users where ID_number = '$ID_number'
		limit 1";

		$DB = new Connect();
		$result= $DB->read($query);

		if($result)
		{
			$row = $result[0];
			if($Password == $row['Password'])
			{
				//create session
				$_SESSION['MPAAA_ID_number'] = $row['ID_number'];

			}else
			{
				$this->error .= "wrong Password/ID_number<br>";
			}

		}else
			{
				$this->error .= "wrong Password/ID_number<br>";
			}
		return $this->error;

	}
	public function check_login($id)
	{
		$query = "select ID_number from users where ID_number = '$id'
		limit 1";

		$DB = new Connect();
		$result= $DB->read($query);

		if($result)
		{
			return true;
		}
		return false;

	}
}
?>