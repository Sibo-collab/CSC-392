<?php

class SalesSignup
{
	private $error="";

	public function evaluate($data)
	{
		foreach ($data as $key => $value)
	 	{
			// code...
			if(empty($value))
			{
				$this->error = $this->error . $key . "is empty! <br>";
			}

			if($key == "Firstname")
			{
				if(is_numeric($value))
				{
				$this->error = $this->error . "Firstname cannot be a number! <br>";
				}
			}

			if($key == "Lastname")
			{
				if(is_numeric($value))
				{
				$this->error = $this->error . "Lastname cannot be a number! <br>";
				}
			}

		}

		if($this->error== "")
			{
			//no error
				$this->create_sale($data);

			}else
			{

				return $this->error;

			}
	}

	private function create_sale($data)
	{
		$ID=$this->create_ID();

		$Firstname=$data['Firstname'];
		$Lastname=$data['Lastname'];
		date_default_timezone_set('Africa/Mbabane');
		$PIN=$data['PIN'];
		$gender=$data['gender'];
		$SalesDetails=$data['SalesDetails'];
		$Amount=$data['Amount'];
		$DOB=$data['DOB'];
			$birthdate=$DOB;
			$currentdate=date('Y-m-d');
			$birthdate_obj =new DateTime($birthdate);
			$currentdate_obj=new DateTime($currentdate);
			$diff=$currentdate_obj -> diff ($birthdate_obj);
			$age_years=$diff->y;
				if($age_years<18)
				{
					echo '<script>alert("This Person is UnderAge!!!!\n\n Transaction Illegal")</script>';
					$query = "\n\ninsert into fraudulent_attempts (Firstname,Lastname,DOB,PIN,gender,SalesDetails,Amount) values ('$Firstname','$Lastname','$DOB','$PIN','$gender','$SalesDetails','$Amount')";
					$DB = new Connect();
					$DB->save($query);
				}else
				{
					$query = "\n\ninsert into sales(Firstname,Lastname,DOB,PIN,gender,SalesDetails,Amount)values ('$Firstname','$Lastname','$DOB','$PIN','$gender','$SalesDetails','$Amount')";
					echo '<script>alert("Transaction Legal and Successful")</script>';
					$DB = new Connect();
					$DB->save($query);
				}
		
		

		$Date=$this->create_Date();
		

		


		

	}
	private function create_ID()
	{
		

	}
	private function create_Date()
	{

	}

}
?>