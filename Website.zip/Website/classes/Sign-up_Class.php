<?php

class Signup
{
	private $error="";

	public function evaluate($data)
	{
		foreach ($data as $key => $value)
	 	{
			// code...
			if(empty($value))
			{
				$this->error = $this->error . $key . "is empty! <br>";
			}

			if($key == "Email")
			{
				if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$value))
				{
				$this->error = $this->error . "invalid Email Address! <br>";

				}
			}

			if($key == "Firstname")
			{
				if(is_numeric($value))
				{
				$this->error = $this->error . "Firstname cannot be a number! <br>";
				}
			}

			if($key == "Lastname")
			{
				if(is_numeric($value))
				{
				$this->error = $this->error . "Lastname cannot be a number! <br>";
				}
			}
			

		}

		if($this->error== "")
			{
			//no error
				$this->create_user($data);

			}else
			{

				return $this->error;

			}
	}

	public function create_user($data)
	{
		$ID=$this->create_ID();

		$Firstname=$data['Firstname'];
		$Lastname=$data['Lastname'];
		$Gender=$data['Gender'];
		$ID_number=$data['ID_number'];
		$Email=$data['Email'];
		$Password=$data['Password'];

		$Date=$this->create_Date();


		$query = "insert into users
		(Firstname,Lastname,Gender,ID_number,Email,Password)
		 values 
		 ('$Firstname','$Lastname','$Gender','$ID_number','$Email','$Password')";
		$DB = new Connect();
		$DB->save($query);
	}
	private function create_ID()
	{
		

	}
	private function create_Date()
	{

	}

}
?>