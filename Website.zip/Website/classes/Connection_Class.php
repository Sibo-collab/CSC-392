<?php

class Connect{

	private $user = "root";
	private $password = "";
	private $db = "minor_protection";
	private $host = "localhost";


	function conn()
	{
	$connect = mysqli_connect("$this->host","$this->user","$this->password","$this->db"); 
	return $connect;
	}

	function read($query)
	{
		$con = $this->conn();
		$result = mysqli_query($con,$query);

		if(!$result)
		{
			return false;

		}else

		{
			$data = false;
			while($row=mysqli_fetch_assoc($result))
			{
				$data[] =$row;
			}
			return $data;
		}

	}

	function save($query)
	{
		$con = $this->conn();
		$result = mysqli_query($con,$query);
		if(!$result)
		{
			return false;

		}else{
			return true;
		}

	}


}

